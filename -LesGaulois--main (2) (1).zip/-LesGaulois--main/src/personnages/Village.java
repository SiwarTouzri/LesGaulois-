package personnages;

public class Village {

}
